﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
           @"Server=DESKTOP-D6UISOH\SQLEXPRESS;Database=CarDealer;Integrated Security=True";
    }
}
