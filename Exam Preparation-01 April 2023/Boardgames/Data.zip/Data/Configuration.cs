﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-D6UISOH\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
