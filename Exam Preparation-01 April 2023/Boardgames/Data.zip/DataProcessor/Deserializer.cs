﻿namespace Boardgames.DataProcessor
{
    using System.ComponentModel.DataAnnotations;
    using System.Text;
    using System.Xml.Serialization;
    using AutoMapper;
    using Boardgames.Data;
    using Boardgames.Data.Models;
    using Boardgames.Data.Models.Enums;
    using Boardgames.DataProcessor.ImportDto;
    using Invoices.Extensions;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedCreator
            = "Successfully imported creator – {0} {1} with {2} boardgames.";

        private const string SuccessfullyImportedSeller
            = "Successfully imported seller - {0} with {1} boardgames.";
        private static Mapper GetMapper()
        {
            var cfg = new MapperConfiguration(c => c.AddProfile<BoardgamesProfile>());
            return new Mapper(cfg);
        }
        public static string ImportCreators(BoardgamesContext context, string xmlString)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportCreatorDTO[]), new XmlRootAttribute("Creators"));
            using var reader = new StringReader(xmlString);
            ImportCreatorDTO[] creatorsDTO = (ImportCreatorDTO[])xmlSerializer.Deserialize(reader);
            var mapper = GetMapper();
            StringBuilder stringBuilder =new StringBuilder();
            List<Creator> creators= new List<Creator>();
            foreach (var creator in creatorsDTO)
            {
                if (!IsValid(creator))
                {
                    stringBuilder.AppendLine(ErrorMessage);
                    continue;
                }
                var creatortoAdd = new Creator()
                {
                    FirstName= creator.FirstName,
                    LastName= creator.LastName,
                };
                foreach (var boargame in creator.Boardgames)
                {
                    if (IsValid(boargame))
                    {
                        creatortoAdd.Boardgames.Add(new Boardgame()
                        { 
                            Name= boargame.Name,
                            Rating= boargame.Rating,
                            YearPublished= boargame.YearPublished,
                            CategoryType= (CategoryType)boargame.CategoryType,
                            Mechanics= boargame.Mechanics,
                        });
                    }
                    else
                    {
                        stringBuilder.AppendLine(ErrorMessage);
                        continue;
                    }
                }
                creators.Add(creatortoAdd);
                stringBuilder.AppendLine(string.Format(SuccessfullyImportedCreator, creatortoAdd.FirstName, creatortoAdd.LastName, creatortoAdd.Boardgames.Count));
            }
            context.Creators.AddRange(creators);
            context.SaveChanges();
            return stringBuilder.ToString();
        }

        public static string ImportSellers(BoardgamesContext context, string jsonString)
        {
            StringBuilder sb = new();
            ImportSellerDTO[] importSellerDTOs = JsonSerializationExtension.DeserializeFromJson<ImportSellerDTO[]>(jsonString);
            List<Seller> sellers = new List<Seller>();
            var uniquesgamesIds = context.Boardgames.Select(bg => bg.Id).ToArray();

            foreach (var sellerDto in importSellerDTOs)
            {
                if (!IsValid(sellerDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var sellertoAdd = new Seller()
                { 
                    Name=sellerDto.Name,
                    Address=sellerDto.Address,
                    Country=sellerDto.Country,
                    Website=sellerDto.Website,
                };
                foreach (var sellerDtoBoardGames in sellerDto.BoardGamesIds.Distinct())
                {
                    if (!uniquesgamesIds.Contains(sellerDtoBoardGames))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }
                    BoardgameSeller bgs=new BoardgameSeller()
                    {
                        SellerId=sellertoAdd.Id,
                        BoardgameId=sellerDtoBoardGames
                    };
                    sellertoAdd.BoardgamesSellers.Add(bgs);
                }
                sellers.Add(sellertoAdd);
                sb.AppendLine(string.Format(SuccessfullyImportedSeller,sellertoAdd.Name,sellertoAdd.BoardgamesSellers.Count()));
            }
            context.AddRange(sellers);
            context.SaveChanges();
            return sb.ToString();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}
