﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-D6UISOH\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}